---
name: research-inception
description: "Initialize a research project structure with CLAUDE.md, INDEX.md, DECISIONS.md, glossary.md, and topic stubs. Use when starting a new research effort from scratch."
disable-model-invocation: true
model: opus
allowed-tools: Read, Glob, Write, Edit
---

# Research Inception

You are initializing a new research project. This is an interactive, Socratic phase — guide the user through defining their research scope before generating any files.

## Phase 1: Discovery (Interactive)

Have a conversation with the user to understand:

1. **Research domain** — What broad area are we researching?
2. **Goals** — What practical outcomes should this knowledge base support?
3. **Topics** — What specific topics should be covered? Help the user brainstorm and refine. For each topic, clarify:
   - Is it standalone or part of a group (directory)?
   - What's the expected scope (brief overview vs. deep dive)?
   - Are there known relationships to other topics?
4. **Conventions** — Ask about:
   - Preferred tone (technical, accessible, mixed)
   - Citation style preferences (inline links, reference sections, both)
   - Any domain-specific terminology conventions
   - Target audience beyond "humans and AI"
5. **Scope boundaries** — What is explicitly *out of scope*?

Ask these questions naturally, not as a checklist. Build on the user's answers. Summarize your understanding and confirm before proceeding to file generation.

## Phase 2: File Generation

Once the user confirms the research plan, generate the following files under `research/`:

### `research/CLAUDE.md`

This file guides all future research phases. Include:

- Research domain and goals (from discovery)
- Tone and writing conventions
- Citation style and reference format
- Section structure expectations
- Cross-reference conventions: use `[display text](relative-path.md#heading-slug)` relative to `content/`
- Any domain-specific rules discovered during the conversation

The reference format for all topic files is:

```
### References

- **title**: "Name of the resource"
  **url**: <link>
  **published**: <date>
  **last-checked**: <date>
  **verified**: true | false
  **takeaway**: "One-sentence conclusion relevant to this section"
```

### `research/INDEX.md`

Structure:

```markdown
# <Research Project Title>
<abstract — 2-3 sentences describing the research scope and goals>

## <directory-name>/
<abstract for this topic group>

### <directory-name>/<topic-file>.md
**Status**: stub

<1-2 sentence abstract>

## <standalone-topic>.md
**Status**: stub

<1-2 sentence abstract>
```

Rules:
- Directory entries (`##`) group child topics, no status field
- Leaf topic files (`###` under a directory, or `##` if standalone) carry `**Status**: stub`
- Use the relative path from `content/` as the heading identifier
- Order topics logically, not alphabetically

### `research/DECISIONS.md`

```markdown
# Decisions

This log records decisions made during research — source selection, scope exclusions, contradictions resolved, and turning points where conclusions changed.

| ID | Date | Topic | Decision | Rationale |
|----|------|-------|----------|-----------|

## Decision Details

<!-- Entries will be added as:

### DEC-001: <title>
**Date**: YYYY-MM-DD
**Topic**: <topic-file-path>
**Context**: <what prompted this decision>
**Decision**: <what was decided>
**Rationale**: <why>
**Alternatives considered**: <what else was weighed>

-->
```

### `research/glossary.md`

```markdown
---
title: "Glossary"
created: <today>
updated: <today>
---

# Glossary

<!-- Terms are organized by domain area. Each area is a heading.
     Format: **term**: definition
     Add a reference link if the definition comes from an authoritative source. -->
```

Leave the glossary empty — it will be populated during investigation and glossary-sync.

### Topic files in `research/content/`

For each topic identified during discovery, create a file with:

```markdown
---
title: "<Topic Title>"
created: <today>
updated: <today>
---

# <Topic Title>
```

Create directories as needed for grouped topics. The files are intentionally minimal stubs — the inquiry phase adds structure.

### `research/assets/`

Create this directory (add a `.gitkeep` if empty).

## Phase 3: Summary

After generating all files, present:
- A tree view of what was created
- The full INDEX.md content for review
- A reminder that the next step is `/research-inquiry <topic-file>` for each topic

## Git

Do NOT commit. The user will review and use `/commit` when ready.
The expected commit message format for this phase is:
`research(inception): initialize project structure`

## Important Rules

- Do NOT create a root `CLAUDE.md` — that is out of scope for this skill.
- All paths are relative to the repository root unless stated otherwise.
- Topic filenames use lowercase with hyphens, no numeric prefixes.
- Today's date for frontmatter: use the current date in YYYY-MM-DD format.
